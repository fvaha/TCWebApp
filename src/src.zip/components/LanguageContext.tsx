import React, {
  createContext,
  useContext,
  useState,
  useMemo,
  useEffect,
} from "react";

/* ---------------- paths ---------------- */
/* This file is in src/components, so one level up to reach locales */
import { locales, languages } from "../locales";

/* ---------------- type inference ---------------- */
/* Take the shape of the English file as the canonical structure */
type Translation = (typeof locales)["en"];

/* ---------------- context ---------------- */
type LangContextType = {
  lang: string;
  setLang: (lang: string) => void;
  t: Translation;
  languages: typeof languages;
};

const LangContext = createContext<LangContextType | undefined>(undefined);

export function useLang(): LangContextType {
  const ctx = useContext(LangContext);
  if (!ctx) {
    throw new Error("useLang must be used within LangProvider");
  }
  return ctx;
}

/* ---------------- provider ---------------- */
export const LangProvider: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  // initial language: saved value or "en"
  const [lang, setLang] = useState(() => localStorage.getItem("lang") ?? "en");

  // persist whenever it changes
  useEffect(() => {
    localStorage.setItem("lang", lang);
  }, [lang]);

  // memoise the context value
  const value = useMemo(
    () => ({
      lang,
      setLang,
      t: locales[lang] ?? locales.en,
      languages,
    }),
    [lang]
  );

  return <LangContext.Provider value={value}>{children}</LangContext.Provider>;
};
