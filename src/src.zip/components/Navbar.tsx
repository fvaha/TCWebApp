import React, { useEffect, useState, useRef } from "react";
import { TbSun, TbMoon, TbMenu2 } from "react-icons/tb";
import { useLang } from "../components/LanguageContext";

type NavbarProps = {
  toggleDark: () => void;
};

const Navbar: React.FC<NavbarProps> = ({ toggleDark }) => {
  /* ---------- dark-mode toggle ---------- */
  const [isDark, setIsDark] = useState(false);
  useEffect(() => {
    setIsDark(document.documentElement.classList.contains("dark"));
  }, []);
  const handleToggleDark = () => {
    toggleDark();
    setIsDark((prev) => !prev);
  };

  /* ---------- language context ---------- */
  const { t, lang, setLang, languages } = useLang();
  const [showLang, setShowLang] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!showLang) return;
    const handleClickOutside = (e: MouseEvent) => {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setShowLang(false);
      }
    };
    window.addEventListener("mousedown", handleClickOutside);
    return () => window.removeEventListener("mousedown", handleClickOutside);
  }, [showLang]);

  /* ---------- mobile drawer ---------- */
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <nav className="sticky top-0 z-50 bg-white dark:bg-black border-b border-gold/50 transition-colors">
      <div className="max-w-7xl mx-auto flex items-center justify-between py-3 px-6">
        {/* Logo */}
        <span className="text-xl font-bold text-gold">TerraCrypt</span>

        {/* ---------- desktop navigation ---------- */}
        <div className="hidden md:flex items-center space-x-4">
          <div className="flex space-x-6">
            <a
              href="#features"
              className="hover:text-gold font-medium transition"
            >
              {t.nav.features}
            </a>
            <a href="#faq" className="hover:text-gold font-medium transition">
              {t.nav.faq}
            </a>
            <a
              href="#contact"
              className="hover:text-gold font-medium transition"
            >
              {t.nav.contact}
            </a>
          </div>

          {/* dark-mode toggle */}
          <button
            onClick={handleToggleDark}
            className="p-2 rounded bg-neutral-200 text-neutral-800 hover:bg-gold hover:text-neutral-900
                       dark:bg-neutral-800 dark:hover:bg-gold dark:text-white dark:hover:text-neutral-900 transition"
            aria-label="Toggle dark mode"
          >
            {isDark ? (
              <TbSun className="w-5 h-5" />
            ) : (
              <TbMoon className="w-5 h-5" />
            )}
          </button>

          {/* language dropdown */}
          <div className="relative ml-2" ref={langRef}>
            <button
              className="rounded border border-gold px-3 py-1 text-sm font-medium hover:bg-gold/20"
              onClick={() => setShowLang((v) => !v)}
            >
              {languages.find((l) => l.code === lang)?.label ?? lang}
            </button>

            {showLang && (
              <div className="absolute right-0 mt-2 w-32 rounded border border-gold bg-white dark:bg-neutral-900 shadow">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLang(l.code);
                      setShowLang(false);
                    }}
                    className={`block w-full px-4 py-2 text-left hover:bg-gold/20 dark:hover:bg-gold/40 ${
                      lang === l.code ? "font-bold text-gold" : ""
                    }`}
                  >
                    {l.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* ---------- mobile top-bar ---------- */}
        <div className="md:hidden flex items-center space-x-2">
          <button
            onClick={handleToggleDark}
            className="p-2 rounded bg-neutral-200 text-neutral-800 hover:bg-gold hover:text-neutral-900
                       dark:bg-neutral-800 dark:hover:bg-gold dark:text-white dark:hover:text-neutral-900 transition"
            aria-label="Toggle dark mode"
          >
            {isDark ? (
              <TbSun className="w-5 h-5" />
            ) : (
              <TbMoon className="w-5 h-5" />
            )}
          </button>

          {/* compact language button */}
          <div className="relative" ref={langRef}>
            <button
              className="rounded border border-gold px-2 py-1 text-xs font-semibold text-gold hover:bg-gold hover:text-black transition"
              onClick={() => setShowLang((v) => !v)}
              aria-label="Change language"
            >
              {lang}
            </button>

            {showLang && (
              <div className="absolute right-0 mt-2 w-28 rounded border border-gold bg-white dark:bg-neutral-900 shadow">
                {languages.map((l) => (
                  <button
                    key={l.code}
                    onClick={() => {
                      setLang(l.code);
                      setShowLang(false);
                    }}
                    className={`block w-full px-3 py-1.5 text-left text-sm hover:bg-gold/20 dark:hover:bg-gold/40 ${
                      lang === l.code ? "font-bold text-gold" : ""
                    }`}
                  >
                    {l.code}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* hamburger */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 rounded text-neutral-800 dark:text-white hover:bg-neutral-200 dark:hover:bg-neutral-800 transition"
            aria-label="Toggle menu"
          >
            <TbMenu2 className="w-6 h-6" />
          </button>
        </div>
      </div>

      {/* ---------- mobile drawer ---------- */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white dark:bg-black py-2 px-4 border-t border-gold/10">
          <div className="flex flex-col space-y-3">
            <a
              href="#features"
              className="hover:text-gold font-medium transition py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {t.nav.features}
            </a>
            <a
              href="#faq"
              className="hover:text-gold font-medium transition py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {t.nav.faq}
            </a>
            <a
              href="#contact"
              className="hover:text-gold font-medium transition py-2"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              {t.nav.contact}
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
