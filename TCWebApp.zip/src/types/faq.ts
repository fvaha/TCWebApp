export interface FaqItem {
  question: string;
  answer: string[];
  points?: string[];
}
